<template>
<!-- 根组件只放容器 -->
    <router-view/>
</template>

<style lang="less">

</style>
