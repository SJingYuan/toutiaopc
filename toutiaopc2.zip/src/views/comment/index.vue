<template>
<el-card>
  <bread-crumb slot="header">
  <template slot="title">
  评论
  </template>
  </bread-crumb>
</el-card>
</template>

<script>
export default {

}
</script>

<style>

</style>
